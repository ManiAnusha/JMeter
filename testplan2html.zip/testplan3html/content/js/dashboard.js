/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 92.6470588235294, "KoPercent": 7.352941176470588};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5882352941176471, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Login/img/favicon.ico-152"], "isController": false}, {"data": [0.0, 500, 1500, "SelectTshirts/index.php-155"], "isController": false}, {"data": [0.0, 500, 1500, "Login/-140"], "isController": false}, {"data": [0.0, 500, 1500, "Login/index.php-141"], "isController": false}, {"data": [1.0, 500, 1500, "SelectTshirts/favicon.ico-156"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blockcurrencies/blockcurrencies.css-150"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/autoload/responsive-tables.css-147"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blockcategories/blockcategories.css-149"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/autoload/highdpi.css-146"], "isController": false}, {"data": [0.0, 500, 1500, "Login/-140-1"], "isController": false}, {"data": [0.0, 500, 1500, "Login/-140-0"], "isController": false}, {"data": [0.0, 500, 1500, "Login/themes/default-bootstrap/css/global.css-145"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/blockfacebook/css/blockfacebook.css-151"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/autoload/uniform.default.css-148"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 68, 5, 7.352941176470588, 3663.7941176470576, 4, 19052, 310.0, 13006.2, 18299.3, 19052.0, 1.4976324193370776, 45.626234548783174, 0.5620208058033256], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Login/img/favicon.ico-152", 5, 0, 0.0, 287.0, 248, 325, 293.0, 325.0, 325.0, 325.0, 0.1584384308257811, 0.5025468977755244, 0.05291596029532924], "isController": false}, {"data": ["SelectTshirts/index.php-155", 5, 1, 20.0, 8011.0, 305, 12913, 8891.0, 12913.0, 12913.0, 12913.0, 0.1260938642725645, 5.599207894106373, 0.05528920415857565], "isController": false}, {"data": ["Login/-140", 5, 1, 20.0, 14986.2, 655, 19052, 18401.0, 19052.0, 19052.0, 19052.0, 0.25793139025019346, 16.664937048620065, 0.16322220789270053], "isController": false}, {"data": ["Login/index.php-141", 5, 2, 40.0, 8263.8, 277, 14507, 12376.0, 14507.0, 14507.0, 14507.0, 0.1576590780097118, 7.6310380963454625, 0.056196839329633604], "isController": false}, {"data": ["SelectTshirts/favicon.ico-156", 5, 0, 0.0, 280.2, 251, 302, 279.0, 302.0, 302.0, 302.0, 0.18506181064475535, 0.8188623672181509, 0.06524151722925457], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blockcurrencies/blockcurrencies.css-150", 5, 0, 0.0, 304.8, 284, 317, 307.0, 317.0, 317.0, 317.0, 0.1574951963965099, 0.32544905817872555, 0.05859928694049831], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/autoload/responsive-tables.css-147", 5, 0, 0.0, 296.4, 253, 350, 308.0, 350.0, 350.0, 350.0, 0.15748527512677565, 0.25745151422092033, 0.056596270748685], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blockcategories/blockcategories.css-149", 5, 0, 0.0, 289.4, 225, 335, 307.0, 335.0, 335.0, 335.0, 0.15853387868987603, 0.46445472272424615, 0.05898574978597926], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/autoload/highdpi.css-146", 5, 0, 0.0, 276.8, 222, 320, 286.0, 320.0, 320.0, 320.0, 0.15854393252370233, 0.08980027428100328, 0.05542844515965374], "isController": false}, {"data": ["Login/-140-1", 4, 0, 0.0, 10889.75, 10500, 11294, 10882.5, 11294.0, 11294.0, 11294.0, 0.337126000842815, 27.08580251790982, 0.12016698272229245], "isController": false}, {"data": ["Login/-140-0", 4, 0, 0.0, 7677.5, 7382, 7897, 7715.5, 7897.0, 7897.0, 7897.0, 0.4944375772558715, 0.1477518541409147, 0.17189431396786156], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/global.css-145", 5, 1, 20.0, 1387.0, 4, 1843, 1682.0, 1843.0, 1843.0, 1843.0, 0.15117157974300832, 24.965838766061978, 0.04109977324263038], "isController": false}, {"data": ["Login/modules/blockfacebook/css/blockfacebook.css-151", 5, 0, 0.0, 272.6, 221, 304, 273.0, 304.0, 304.0, 304.0, 0.1583581427757015, 0.04345570128903528, 0.0544356115791474], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/autoload/uniform.default.css-148", 5, 0, 0.0, 318.6, 218, 361, 349.0, 361.0, 361.0, 361.0, 0.1576590780097118, 1.9208541574698872, 0.05635080327300246], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["508/Loop Detected", 4, 80.0, 5.882352941176471], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: automationpractice.com:80 failed to respond", 1, 20.0, 1.4705882352941178], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 68, 5, "508/Loop Detected", 4, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: automationpractice.com:80 failed to respond", 1, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["SelectTshirts/index.php-155", 5, 1, "508/Loop Detected", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Login/-140", 5, 1, "508/Loop Detected", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["Login/index.php-141", 5, 2, "508/Loop Detected", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/global.css-145", 5, 1, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: automationpractice.com:80 failed to respond", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
