/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.4059405940594, "KoPercent": 0.594059405940594};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9405940594059405, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "ClickWomen/js/jquery/ui/themes/base/images/ui-bg_flat_75_ffffff_40x100.png-121"], "isController": false}, {"data": [1.0, 500, 1500, "Login/img/p/2/0/20-home_default.jpg-82"], "isController": false}, {"data": [1.0, 500, 1500, "Login/js/jquery/plugins/jquery.scrollTo.js-68"], "isController": false}, {"data": [1.0, 500, 1500, "Login/img/p/1/2/12-home_default.jpg-78"], "isController": false}, {"data": [1.0, 500, 1500, "Login/img/p/8/8-home_default.jpg-77"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/global.js-59"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blockcurrencies/blockcurrencies.css-28"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/editorial/css/editorial.css-39"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/product_list.css-25"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blockviewed/blockviewed.css-45"], "isController": false}, {"data": [1.0, 500, 1500, "Login/img/p/7/7-home_default.jpg-76"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/modules/blockstore/store.jpg-114"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/js/jquery/ui/themes/base/images/ui-bg_glass_75_e6e6e6_1x400.png-123"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/modules/blockcart/ajax-cart.js-66"], "isController": false}, {"data": [1.0, 500, 1500, "Login/js/jquery/plugins/fancybox/jquery.fancybox.js-55"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/autoload/highdpi.css-22"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/js/jquery/ui/themes/base/jquery.ui.slider.css-107"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/js/jquery/ui/jquery.ui.mouse.min.js-112"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/js/jquery/ui/jquery.ui.core.min.js-110"], "isController": false}, {"data": [1.0, 500, 1500, "Login/js/jquery/plugins/jquery.easing.js-47"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/themes/default-bootstrap/css/category.css-102"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/themes/default-bootstrap/js/modules/blocklayered/blocklayered.js-109"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blockcart/blockcart.css-26"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/js/jquery/ui/jquery.ui.widget.min.js-111"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/autoload/uniform.default.css-24"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/themeconfigurator/img/banner-img7.jpg-90"], "isController": false}, {"data": [1.0, 500, 1500, "Login/js/jquery/jquery-migrate-1.2.1.min.js-50"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/img/c/3-category_default.jpg-119"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/themeconfigurator/img/banner-img5.jpg-91"], "isController": false}, {"data": [0.5, 500, 1500, "Login/themes/default-bootstrap/js/autoload/15-jquery.uniform-modified.js-53"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/themeconfigurator/img/banner-img3.jpg-84"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blocktopmenu/css/blocktopmenu.css-43"], "isController": false}, {"data": [1.0, 500, 1500, "Login/img/logo.jpg-75"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/tools/treeManagement.js-63"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/index.js-67"], "isController": false}, {"data": [0.5, 500, 1500, "Login/modules/homeslider/images/sample-2.jpg-89"], "isController": false}, {"data": [1.0, 500, 1500, "Login/js/jquery/plugins/fancybox/jquery.fancybox.css-23"], "isController": false}, {"data": [0.8, 500, 1500, "Login/modules/homeslider/images/sample-3.jpg-87"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/js/jquery/ui/jquery.ui.slider.min.js-113"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/img/c/8-medium_default.jpg-118"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/productcomments/productcomments.css-34"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/modules/homeslider/js/homeslider.js-61"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blockuserinfo/blockuserinfo.css-32"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/modules/blockwishlist/js/ajax-wishlist.js-71"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/themeconfigurator/img/banner-img4.jpg-83"], "isController": false}, {"data": [0.2, 500, 1500, "Login/themes/default-bootstrap/css/global.css-21"], "isController": false}, {"data": [1.0, 500, 1500, "Login/img/p/1/0/10-home_default.jpg-80"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blocktopmenu/css/superfish-modified.css-38"], "isController": false}, {"data": [1.0, 500, 1500, "Login/img/p/1/6/16-home_default.jpg-93"], "isController": false}, {"data": [1.0, 500, 1500, "Login/js/jquery/plugins/jquery.serialScroll.js-60"], "isController": false}, {"data": [1.0, 500, 1500, "Login/css-70"], "isController": false}, {"data": [0.5, 500, 1500, "Login/js/jquery/jquery-1.11.0.min.js-33"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/js/jquery/ui/themes/base/images/ui-bg_highlight-soft_75_cccccc_1x100.png-122"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/homeslider/homeslider.css-42"], "isController": false}, {"data": [0.9, 500, 1500, "Login/themes/default-bootstrap/css/modules/blocknewsletter/blocknewsletter.css-31"], "isController": false}, {"data": [0.0, 500, 1500, "ClickWomen/index.php-101"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blockwishlist/blockwishlist.css-36"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blockcategories/blockcategories.css-35"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/modules/blocknewsletter/blocknewsletter.js-57"], "isController": false}, {"data": [0.5, 500, 1500, "Login/themes/default-bootstrap/font/fontawesome-webfont.woff-95"], "isController": false}, {"data": [1.0, 500, 1500, "Login/img/p/1/1-home_default.jpg-92"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/themes/default-bootstrap/css/scenes.css-103"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blocktags/blocktags.css-41"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blocklanguages/blocklanguages.css-54"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/modules/blocktopmenu/js/superfish-modified.js-69"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/themes/default-bootstrap/css/modules/blocklayered/blocklayered.css-105"], "isController": false}, {"data": [1.0, 500, 1500, "Login/img/c/3-0_thumb.jpg-73"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/modules/blocktopmenu/js/blocktopmenu.js-72"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blocksearch/blocksearch.css-40"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blockbanner/blockbanner.css-46"], "isController": false}, {"data": [1.0, 500, 1500, "Login/js/jquery/plugins/bxslider/jquery.bxslider.js-65"], "isController": false}, {"data": [1.0, 500, 1500, "Login/js/jquery/plugins/autocomplete/jquery.autocomplete.js-62"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/img/p/1/2/12-small_default.jpg-117"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/themes/default-bootstrap/img/jquery/uniform/sprite.png-120"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/blockfacebook/css/blockfacebook.css-29"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/themes/default-bootstrap/js/category.js-108"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/products-comparison.js-51"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/themeconfigurator/img/banner-img2.jpg-86"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/themeconfigurator/img/banner-img6.jpg-88"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/modules/blocksearch/blocksearch.js-56"], "isController": false}, {"data": [0.0, 500, 1500, "Login/index.php-9"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/js/jquery/ui/themes/base/jquery.ui.theme.css-104"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/themeconfigurator/css/hooks.css-48"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/modules/blocktopmenu/js/hoverIntent.js-64"], "isController": false}, {"data": [0.7, 500, 1500, "Login/modules/homeslider/images/sample-1.jpg-81"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/img/c/4-medium_default.jpg-115"], "isController": false}, {"data": [1.0, 500, 1500, "Login/img/c/3-1_thumb.jpg-74"], "isController": false}, {"data": [0.5, 500, 1500, "Login/modules/themeconfigurator/img/banner-img1.jpg-85"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/blockcontact/blockcontact.css-27"], "isController": false}, {"data": [1.0, 500, 1500, "Login/js/tools.js-49"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/blockbanner/img/sale70.png-79"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/js/autoload/15-jquery.total-storage.min.js-52"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/img/footer-bg.png-94"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/modules/homeslider/images/bx_loader.gif-97"], "isController": false}, {"data": [1.0, 500, 1500, "Login/img/favicon.ico-99"], "isController": false}, {"data": [1.0, 500, 1500, "Login/themes/default-bootstrap/css/autoload/responsive-tables.css-30"], "isController": false}, {"data": [1.0, 500, 1500, "Login/js/jquery/plugins/autocomplete/jquery.autocomplete.css-37"], "isController": false}, {"data": [0.9, 500, 1500, "Login/themes/default-bootstrap/js/autoload/10-bootstrap.min.js-44"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/js/jquery/ui/themes/base/jquery.ui.core.css-106"], "isController": false}, {"data": [1.0, 500, 1500, "Login/modules/blockfacebook/blockfacebook.js-58"], "isController": false}, {"data": [1.0, 500, 1500, "ClickWomen/img/loader.gif-116"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 505, 3, 0.594059405940594, 489.7801980198022, 97, 15991, 273.0, 463.4000000000002, 701.0999999999999, 11398.3, 8.401683664132298, 126.13835080044754, 2.9875108140482807], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["ClickWomen/js/jquery/ui/themes/base/images/ui-bg_flat_75_ffffff_40x100.png-121", 5, 0, 0.0, 264.2, 233, 298, 251.0, 298.0, 298.0, 298.0, 0.265097290705689, 0.08703682532739515, 0.1071780062032766], "isController": false}, {"data": ["Login/img/p/2/0/20-home_default.jpg-82", 5, 0, 0.0, 267.8, 236, 306, 251.0, 306.0, 306.0, 306.0, 0.33397902611715985, 2.6868351730011355, 0.11252223047892593], "isController": false}, {"data": ["Login/js/jquery/plugins/jquery.scrollTo.js-68", 5, 0, 0.0, 301.6, 258, 361, 305.0, 361.0, 361.0, 361.0, 0.32767547021429977, 0.9142273617209515, 0.10559854020578019], "isController": false}, {"data": ["Login/img/p/1/2/12-home_default.jpg-78", 5, 0, 0.0, 282.4, 250, 309, 297.0, 309.0, 309.0, 309.0, 0.33331111259249385, 2.8061280289647357, 0.11229720101993201], "isController": false}, {"data": ["Login/img/p/8/8-home_default.jpg-77", 5, 0, 0.0, 245.4, 223, 265, 252.0, 265.0, 265.0, 265.0, 0.33435870001337437, 2.2435338162030227, 0.11167058144977932], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/global.js-59", 5, 0, 0.0, 288.8, 235, 307, 306.0, 307.0, 307.0, 307.0, 0.32480187085877615, 4.466025724308172, 0.10498966724048331], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blockcurrencies/blockcurrencies.css-28", 5, 0, 0.0, 283.8, 218, 327, 310.0, 327.0, 327.0, 327.0, 0.31713814537612584, 0.655336245718635, 0.11799768885576557], "isController": false}, {"data": ["Login/modules/editorial/css/editorial.css-39", 5, 0, 0.0, 275.6, 251, 307, 257.0, 307.0, 307.0, 307.0, 0.31403090064062306, 0.2493233615437759, 0.1054947556839593], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/product_list.css-25", 5, 0, 0.0, 282.2, 221, 336, 309.0, 336.0, 336.0, 336.0, 0.31727901516593693, 5.113335534456501, 0.10968434703978679], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blockviewed/blockviewed.css-45", 5, 0, 0.0, 259.6, 231, 290, 258.0, 290.0, 290.0, 290.0, 0.31314586334314526, 0.11528905320348218, 0.11406582717479802], "isController": false}, {"data": ["Login/img/p/7/7-home_default.jpg-76", 5, 0, 0.0, 256.2, 239, 280, 255.0, 280.0, 280.0, 280.0, 0.33456005352960855, 2.514754621110739, 0.11173783037805286], "isController": false}, {"data": ["ClickWomen/modules/blockstore/store.jpg-114", 5, 0, 0.0, 258.0, 233, 290, 252.0, 290.0, 290.0, 290.0, 0.26675202731540765, 2.770469883696116, 0.09846901008322663], "isController": false}, {"data": ["ClickWomen/js/jquery/ui/themes/base/images/ui-bg_glass_75_e6e6e6_1x400.png-123", 5, 0, 0.0, 252.6, 214, 276, 256.0, 276.0, 276.0, 276.0, 0.26561835954101143, 0.08487336644708882, 0.10738867270505736], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/modules/blockcart/ajax-cart.js-66", 5, 0, 0.0, 266.0, 245, 310, 257.0, 310.0, 310.0, 310.0, 0.33424694164048396, 10.167439438632261, 0.11489738618891637], "isController": false}, {"data": ["Login/js/jquery/plugins/fancybox/jquery.fancybox.js-55", 5, 0, 0.0, 264.8, 249, 309, 253.0, 309.0, 309.0, 309.0, 0.33406828355715906, 7.631046113950691, 0.11059487121667669], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/autoload/highdpi.css-22", 5, 0, 0.0, 279.4, 245, 318, 287.0, 318.0, 318.0, 318.0, 0.31367628607277287, 0.17766820890840654, 0.10966417032622335], "isController": false}, {"data": ["ClickWomen/js/jquery/ui/themes/base/jquery.ui.slider.css-107", 5, 0, 0.0, 252.6, 233, 294, 245.0, 294.0, 294.0, 294.0, 0.26984726644719087, 0.4097778313724432, 0.10224681580225592], "isController": false}, {"data": ["ClickWomen/js/jquery/ui/jquery.ui.mouse.min.js-112", 5, 0, 0.0, 249.6, 232, 280, 246.0, 280.0, 280.0, 280.0, 0.2701534471579857, 0.8167920628917226, 0.09576728644370003], "isController": false}, {"data": ["ClickWomen/js/jquery/ui/jquery.ui.core.min.js-110", 5, 0, 0.0, 242.0, 222, 260, 246.0, 260.0, 260.0, 260.0, 0.270811894058387, 1.2017277798840924, 0.09573623598548447], "isController": false}, {"data": ["Login/js/jquery/plugins/jquery.easing.js-47", 5, 0, 0.0, 264.0, 222, 280, 273.0, 280.0, 280.0, 280.0, 0.3129694541812719, 1.5923543518402603, 0.10024802829243865], "isController": false}, {"data": ["ClickWomen/themes/default-bootstrap/css/category.css-102", 5, 0, 0.0, 308.2, 232, 457, 294.0, 457.0, 457.0, 457.0, 0.26884611248521345, 0.776713221851812, 0.10081729218195505], "isController": false}, {"data": ["ClickWomen/themes/default-bootstrap/js/modules/blocklayered/blocklayered.js-109", 5, 0, 0.0, 281.0, 248, 341, 256.0, 341.0, 341.0, 341.0, 0.2678667095253402, 5.487605305100182, 0.10254272474016929], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blockcart/blockcart.css-26", 5, 0, 0.0, 314.4, 290, 327, 322.0, 327.0, 327.0, 327.0, 0.31246094238220223, 4.445245125609299, 0.11259578880764905], "isController": false}, {"data": ["ClickWomen/js/jquery/ui/jquery.ui.widget.min.js-111", 5, 0, 0.0, 287.6, 251, 318, 307.0, 318.0, 318.0, 318.0, 0.2691210506485817, 1.7721516059798696, 0.09566412347273803], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/autoload/uniform.default.css-24", 5, 0, 0.0, 273.6, 246, 311, 257.0, 311.0, 311.0, 311.0, 0.3125586047383884, 3.8080870631993498, 0.11171528255297869], "isController": false}, {"data": ["Login/modules/themeconfigurator/img/banner-img7.jpg-90", 5, 0, 0.0, 279.4, 222, 306, 304.0, 306.0, 306.0, 306.0, 0.33215970238490666, 8.74514216435262, 0.117099270079054], "isController": false}, {"data": ["Login/js/jquery/jquery-migrate-1.2.1.min.js-50", 5, 0, 0.0, 276.8, 225, 308, 306.0, 308.0, 308.0, 308.0, 0.3157761778451434, 2.2986285445875962, 0.10207218248705317], "isController": false}, {"data": ["ClickWomen/img/c/3-category_default.jpg-119", 5, 0, 0.0, 268.6, 226, 306, 269.0, 306.0, 306.0, 306.0, 0.2658584569575158, 7.543785641649387, 0.098139156962833], "isController": false}, {"data": ["Login/modules/themeconfigurator/img/banner-img5.jpg-91", 5, 0, 0.0, 285.0, 232, 309, 295.0, 309.0, 309.0, 309.0, 0.33003300330033003, 11.385171720297029, 0.11634952557755775], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/autoload/15-jquery.uniform-modified.js-53", 5, 0, 0.0, 560.2, 511, 618, 551.0, 618.0, 618.0, 618.0, 0.32720371703422546, 11.684431953896995, 0.1150325567698449], "isController": false}, {"data": ["Login/modules/themeconfigurator/img/banner-img3.jpg-84", 5, 0, 0.0, 285.2, 237, 308, 305.0, 308.0, 308.0, 308.0, 0.33062223103881505, 12.03413261257687, 0.11655725137208227], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blocktopmenu/css/blocktopmenu.css-43", 5, 0, 0.0, 269.2, 247, 310, 254.0, 310.0, 310.0, 310.0, 0.31300863903843745, 0.08558829973707274, 0.11584987714410917], "isController": false}, {"data": ["Login/img/logo.jpg-75", 5, 0, 0.0, 268.2, 234, 306, 252.0, 306.0, 306.0, 306.0, 0.33397902611715985, 3.8518479476988845, 0.10697765680315276], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/tools/treeManagement.js-63", 5, 0, 0.0, 270.8, 235, 307, 255.0, 307.0, 307.0, 307.0, 0.3304255881575469, 1.0377428628072958, 0.11132502726011102], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/index.js-67", 5, 0, 0.0, 267.2, 219, 311, 257.0, 311.0, 311.0, 311.0, 0.33209351753453775, 0.44300756342986186, 0.10702232498671627], "isController": false}, {"data": ["Login/modules/homeslider/images/sample-2.jpg-89", 5, 0, 0.0, 754.0, 699, 809, 754.0, 809.0, 809.0, 809.0, 0.32901230506020923, 33.32823964022504, 0.11374058202276766], "isController": false}, {"data": ["Login/js/jquery/plugins/fancybox/jquery.fancybox.css-23", 5, 0, 0.0, 271.2, 253, 310, 262.0, 310.0, 310.0, 310.0, 0.3138534931893792, 1.57417142677798, 0.10880663093967737], "isController": false}, {"data": ["Login/modules/homeslider/images/sample-3.jpg-87", 5, 0, 0.0, 482.6, 438, 512, 497.0, 512.0, 512.0, 512.0, 0.33482890243085783, 19.45146655059265, 0.11575139791066764], "isController": false}, {"data": ["ClickWomen/js/jquery/ui/jquery.ui.slider.min.js-113", 5, 0, 0.0, 263.0, 220, 312, 252.0, 312.0, 312.0, 312.0, 0.2698909640505236, 2.7563668965238044, 0.09593780362733456], "isController": false}, {"data": ["ClickWomen/img/c/8-medium_default.jpg-118", 5, 0, 0.0, 283.2, 251, 305, 303.0, 305.0, 305.0, 305.0, 0.266851683834125, 0.5542905581202968, 0.09798460265784278], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/productcomments/productcomments.css-34", 5, 0, 0.0, 296.4, 236, 316, 312.0, 316.0, 316.0, 316.0, 0.3141887646097775, 2.338619886577856, 0.11690031183234888], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/modules/homeslider/js/homeslider.js-61", 5, 0, 0.0, 274.0, 216, 312, 304.0, 312.0, 312.0, 312.0, 0.3263281555932646, 0.6931286507962408, 0.11376870268241744], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blockuserinfo/blockuserinfo.css-32", 5, 0, 0.0, 248.8, 221, 276, 250.0, 276.0, 276.0, 276.0, 0.3151194302640701, 0.21141313339005482, 0.11601564961870549], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/modules/blockwishlist/js/ajax-wishlist.js-71", 5, 0, 0.0, 300.2, 255, 341, 310.0, 341.0, 341.0, 341.0, 0.33424694164048396, 3.3375732209706532, 0.11848792950732001], "isController": false}, {"data": ["Login/modules/themeconfigurator/img/banner-img4.jpg-83", 5, 0, 0.0, 290.4, 257, 308, 305.0, 308.0, 308.0, 308.0, 0.33018556428712936, 6.134228686521825, 0.11640330928481807], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/global.css-21", 5, 0, 0.0, 1597.0, 1473, 1776, 1616.0, 1776.0, 1776.0, 1776.0, 0.30837547798199083, 63.50246122178365, 0.10479947884544222], "isController": false}, {"data": ["Login/img/p/1/0/10-home_default.jpg-80", 5, 0, 0.0, 280.4, 245, 308, 294.0, 308.0, 308.0, 308.0, 0.33346672002134187, 3.785368313992264, 0.11234962735094038], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blocktopmenu/css/superfish-modified.css-38", 5, 0, 0.0, 306.2, 304, 308, 306.0, 308.0, 308.0, 308.0, 0.3169974006213149, 1.7670128542445953, 0.11918359300703735], "isController": false}, {"data": ["Login/img/p/1/6/16-home_default.jpg-93", 5, 0, 0.0, 288.6, 251, 309, 304.0, 309.0, 309.0, 309.0, 0.3320494089520521, 2.67714835967592, 0.11187211532075973], "isController": false}, {"data": ["Login/js/jquery/plugins/jquery.serialScroll.js-60", 5, 0, 0.0, 287.6, 231, 306, 298.0, 306.0, 306.0, 306.0, 0.3228722717293039, 0.7151116330879503, 0.10531185425545654], "isController": false}, {"data": ["Login/css-70", 5, 0, 0.0, 136.8, 97, 185, 116.0, 185.0, 185.0, 185.0, 0.31717838112154273, 0.3701446928127379, 0.1081008349720883], "isController": false}, {"data": ["Login/js/jquery/jquery-1.11.0.min.js-33", 5, 0, 0.0, 820.2, 693, 923, 803.0, 923.0, 923.0, 923.0, 0.3102506825515016, 29.27899922825143, 0.09816525502606106], "isController": false}, {"data": ["ClickWomen/js/jquery/ui/themes/base/images/ui-bg_highlight-soft_75_cccccc_1x100.png-122", 5, 0, 0.0, 250.6, 229, 264, 251.0, 264.0, 264.0, 264.0, 0.2655055225148683, 0.08431874601741716, 0.10967659767948174], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/homeslider/homeslider.css-42", 5, 0, 0.0, 250.0, 220, 283, 249.0, 283.0, 283.0, 283.0, 0.31283238440843397, 2.0049989637427266, 0.11334063927297754], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blocknewsletter/blocknewsletter.css-31", 5, 0, 0.0, 324.6, 254, 509, 300.0, 509.0, 509.0, 509.0, 0.315059861373661, 0.982100661625709, 0.11722442107750473], "isController": false}, {"data": ["ClickWomen/index.php-101", 5, 0, 0.0, 11846.4, 9856, 13659, 11443.0, 13659.0, 13659.0, 13659.0, 0.17852679687221054, 17.31225257301746, 0.07827981620666262], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blockwishlist/blockwishlist.css-36", 5, 0, 0.0, 283.2, 272, 301, 284.0, 301.0, 301.0, 301.0, 0.3178437480134766, 1.449541311741148, 0.11701864550886784], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blockcategories/blockcategories.css-35", 5, 0, 0.0, 279.4, 247, 340, 253.0, 340.0, 340.0, 340.0, 0.3163956210846042, 0.9269402961463012, 0.11772141761058026], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/modules/blocknewsletter/blocknewsletter.js-57", 5, 0, 0.0, 266.0, 232, 327, 254.0, 327.0, 327.0, 327.0, 0.33550291887539424, 0.6503645448902905, 0.11926080319398778], "isController": false}, {"data": ["Login/themes/default-bootstrap/font/fontawesome-webfont.woff-95", 5, 0, 0.0, 581.0, 527, 613, 590.0, 613.0, 613.0, 613.0, 0.32733224222585927, 14.01614924304419, 0.14192921440261866], "isController": false}, {"data": ["Login/img/p/1/1-home_default.jpg-92", 5, 0, 0.0, 270.0, 246, 311, 256.0, 311.0, 311.0, 311.0, 0.33440342429106473, 2.0599773441680043, 0.11168551865971107], "isController": false}, {"data": ["ClickWomen/themes/default-bootstrap/css/scenes.css-103", 5, 0, 0.0, 252.8, 236, 271, 254.0, 271.0, 271.0, 271.0, 0.27065064414853307, 0.6446454307405002, 0.1009653770163473], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blocktags/blocktags.css-41", 5, 0, 0.0, 240.8, 220, 252, 246.0, 252.0, 252.0, 252.0, 0.3191625175539385, 0.19168451981999235, 0.1150107118919954], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blocklanguages/blocklanguages.css-54", 5, 0, 0.0, 277.2, 218, 312, 298.0, 312.0, 312.0, 312.0, 0.3211922656902422, 0.6223100147748443, 0.11887877802402518], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/modules/blocktopmenu/js/superfish-modified.js-69", 5, 0, 0.0, 266.2, 221, 307, 267.0, 307.0, 307.0, 307.0, 0.32998944033790917, 2.3324839542634637, 0.11826769980860613], "isController": false}, {"data": ["ClickWomen/themes/default-bootstrap/css/modules/blocklayered/blocklayered.css-105", 5, 0, 0.0, 259.2, 242, 307, 248.0, 307.0, 307.0, 307.0, 0.2698909640505236, 0.9612229940354097, 0.10779824638346108], "isController": false}, {"data": ["Login/img/c/3-0_thumb.jpg-73", 5, 0, 0.0, 250.6, 240, 266, 250.0, 266.0, 266.0, 266.0, 0.33433634236041454, 4.420161526245403, 0.10937761200267469], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/modules/blocktopmenu/js/blocktopmenu.js-72", 5, 0, 0.0, 261.8, 216, 311, 251.0, 311.0, 311.0, 311.0, 0.33108197589723215, 1.3220646478943185, 0.11671932939345782], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blocksearch/blocksearch.css-40", 5, 0, 0.0, 301.8, 298, 305, 301.0, 305.0, 305.0, 305.0, 0.31707781089479353, 0.5759421174456212, 0.11549806978882618], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blockbanner/blockbanner.css-46", 5, 0, 0.0, 275.0, 257, 308, 261.0, 308.0, 308.0, 308.0, 0.3179043743641913, 0.13597862887843337, 0.11579915199008138], "isController": false}, {"data": ["Login/js/jquery/plugins/bxslider/jquery.bxslider.js-65", 5, 0, 0.0, 287.0, 243, 308, 306.0, 308.0, 308.0, 308.0, 0.3331556503198294, 6.3049056128398195, 0.11029273970549042], "isController": false}, {"data": ["Login/js/jquery/plugins/autocomplete/jquery.autocomplete.js-62", 5, 0, 0.0, 298.6, 256, 311, 309.0, 311.0, 311.0, 311.0, 0.3329781566329249, 6.570465461840703, 0.11283537143713372], "isController": false}, {"data": ["ClickWomen/img/p/1/2/12-small_default.jpg-117", 5, 0, 0.0, 271.6, 245, 346, 251.0, 346.0, 346.0, 346.0, 0.26516758591429784, 0.62127936731014, 0.09840203383538396], "isController": false}, {"data": ["ClickWomen/themes/default-bootstrap/img/jquery/uniform/sprite.png-120", 5, 0, 0.0, 259.4, 215, 294, 266.0, 294.0, 294.0, 294.0, 0.26566069815631477, 1.0523173084586366, 0.10844352717708941], "isController": false}, {"data": ["Login/modules/blockfacebook/css/blockfacebook.css-29", 5, 0, 0.0, 271.4, 247, 308, 249.0, 308.0, 308.0, 308.0, 0.3169371196754564, 0.08697200256719068, 0.10894713488843813], "isController": false}, {"data": ["ClickWomen/themes/default-bootstrap/js/category.js-108", 5, 0, 0.0, 258.0, 234, 277, 259.0, 277.0, 277.0, 277.0, 0.2701972439881113, 0.3799648743582816, 0.09683827006214538], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/products-comparison.js-51", 5, 0, 0.0, 255.0, 222, 269, 261.0, 269.0, 269.0, 269.0, 0.3139520281301017, 1.4719567256373225, 0.10546825944995604], "isController": false}, {"data": ["Login/modules/themeconfigurator/img/banner-img2.jpg-86", 5, 0, 0.0, 287.0, 234, 309, 305.0, 309.0, 309.0, 309.0, 0.33112582781456956, 10.310171771523178, 0.11673478890728477], "isController": false}, {"data": ["Login/modules/themeconfigurator/img/banner-img6.jpg-88", 5, 0, 0.0, 262.8, 222, 307, 244.0, 307.0, 307.0, 307.0, 0.3356380479291132, 9.66827685523931, 0.11832552275625965], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/modules/blocksearch/blocksearch.js-56", 5, 0, 0.0, 277.6, 233, 308, 289.0, 308.0, 308.0, 308.0, 0.3307534563736191, 1.2871606676258516, 0.114988506317391], "isController": false}, {"data": ["Login/index.php-9", 5, 3, 60.0, 6830.2, 732, 15991, 761.0, 15991.0, 15991.0, 15991.0, 0.305008235222351, 9.895432215732324, 0.10871875571890441], "isController": false}, {"data": ["ClickWomen/js/jquery/ui/themes/base/jquery.ui.theme.css-104", 5, 0, 0.0, 274.4, 250, 308, 273.0, 308.0, 308.0, 308.0, 0.26762297275598135, 4.642108634855216, 0.10114266646148906], "isController": false}, {"data": ["Login/modules/themeconfigurator/css/hooks.css-48", 5, 0, 0.0, 277.4, 233, 326, 272.0, 326.0, 326.0, 326.0, 0.31283238440843397, 0.4915501040167678, 0.10631413063880372], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/modules/blocktopmenu/js/hoverIntent.js-64", 5, 0, 0.0, 282.8, 217, 307, 305.0, 307.0, 307.0, 307.0, 0.3233107015842225, 1.6396020247332688, 0.1136639185257032], "isController": false}, {"data": ["Login/modules/homeslider/images/sample-1.jpg-81", 5, 0, 0.0, 566.2, 467, 702, 554.0, 702.0, 702.0, 702.0, 0.3320714617785748, 24.560965207212593, 0.11479814206017135], "isController": false}, {"data": ["ClickWomen/img/c/4-medium_default.jpg-115", 5, 0, 0.0, 292.6, 250, 344, 284.0, 344.0, 344.0, 344.0, 0.2654491399447866, 0.4762530858462519, 0.09746960607347634], "isController": false}, {"data": ["Login/img/c/3-1_thumb.jpg-74", 5, 0, 0.0, 290.4, 259, 305, 297.0, 305.0, 305.0, 305.0, 0.33242470580413536, 3.3813825543514393, 0.10875222309022006], "isController": false}, {"data": ["Login/modules/themeconfigurator/img/banner-img1.jpg-85", 5, 0, 0.0, 512.6, 504, 530, 505.0, 530.0, 530.0, 530.0, 0.33386752136752135, 14.879601633446848, 0.11770134298210469], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/blockcontact/blockcontact.css-27", 5, 0, 0.0, 300.0, 231, 331, 307.0, 331.0, 331.0, 331.0, 0.3144851877476571, 0.4803269859739607, 0.11516791543493302], "isController": false}, {"data": ["Login/js/tools.js-49", 5, 0, 0.0, 264.0, 225, 309, 255.0, 309.0, 309.0, 309.0, 0.3168166265365606, 5.265838851222912, 0.09436432723989355], "isController": false}, {"data": ["Login/modules/blockbanner/img/sale70.png-79", 5, 0, 0.0, 255.0, 219, 278, 255.0, 278.0, 278.0, 278.0, 0.33456005352960855, 4.396001484610237, 0.11435158079625292], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/autoload/15-jquery.total-storage.min.js-52", 5, 0, 0.0, 262.4, 233, 306, 258.0, 306.0, 306.0, 306.0, 0.31330283852371704, 0.8625006853499593, 0.11045148897174009], "isController": false}, {"data": ["Login/themes/default-bootstrap/img/footer-bg.png-94", 5, 0, 0.0, 256.0, 219, 306, 253.0, 306.0, 306.0, 306.0, 0.33451528734863184, 0.10584272763765305, 0.12674993309694255], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/modules/homeslider/images/bx_loader.gif-97", 5, 0, 0.0, 283.4, 250, 307, 304.0, 307.0, 307.0, 307.0, 0.3313672211544834, 2.855129875240241, 0.14141355043409107], "isController": false}, {"data": ["Login/img/favicon.ico-99", 5, 0, 0.0, 243.6, 232, 255, 247.0, 255.0, 255.0, 255.0, 0.34071550255536626, 1.0807069846678024, 0.1137936541737649], "isController": false}, {"data": ["Login/themes/default-bootstrap/css/autoload/responsive-tables.css-30", 5, 0, 0.0, 271.6, 254, 306, 260.0, 306.0, 306.0, 306.0, 0.31583601793948585, 0.5163178652643547, 0.11350356894700273], "isController": false}, {"data": ["Login/js/jquery/plugins/autocomplete/jquery.autocomplete.css-37", 5, 0, 0.0, 345.2, 306, 372, 370.0, 372.0, 372.0, 372.0, 0.3157562361856647, 0.32747375276286705, 0.11193311888222292], "isController": false}, {"data": ["Login/themes/default-bootstrap/js/autoload/10-bootstrap.min.js-44", 5, 0, 0.0, 401.00000000000006, 223, 1037, 253.0, 1037.0, 1037.0, 1037.0, 0.3162355322244007, 8.612168249161975, 0.10808831667826196], "isController": false}, {"data": ["ClickWomen/js/jquery/ui/themes/base/jquery.ui.core.css-106", 5, 0, 0.0, 262.6, 244, 308, 253.0, 308.0, 308.0, 308.0, 0.26948366928964107, 0.4497535066562467, 0.10158271127519673], "isController": false}, {"data": ["Login/modules/blockfacebook/blockfacebook.js-58", 5, 0, 0.0, 264.6, 220, 308, 247.0, 308.0, 308.0, 308.0, 0.3276969458644645, 0.5040260641958317, 0.10624549416699437], "isController": false}, {"data": ["ClickWomen/img/loader.gif-116", 5, 0, 0.0, 254.2, 219, 305, 249.0, 305.0, 305.0, 305.0, 0.26732249786142004, 1.0333163193701882, 0.09502479416167664], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["508/Loop Detected", 3, 100.0, 0.594059405940594], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 505, 3, "508/Loop Detected", 3, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Login/index.php-9", 5, 3, "508/Loop Detected", 3, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
